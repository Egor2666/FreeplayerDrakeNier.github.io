@echo off
chcp 65001 >nul
title Создание ярлыка

python -c "import vlc, PIL" 2>nul
if errorlevel 1 (
    echo Устанавливаю недостающие компоненты python-vlc и Pillow...
    python -m pip install --quiet python-vlc Pillow
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\make_shortcut.ps1"
echo.
pause
