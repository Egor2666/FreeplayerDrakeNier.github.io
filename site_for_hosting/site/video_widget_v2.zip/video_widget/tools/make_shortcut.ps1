﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$app  = Join-Path $root 'app.py'
$icon = Join-Path $root 'assets\icon.ico'

function Find-PythonW {
    $c = Get-Command pythonw.exe -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) {
        $exe = & py -3 -c "import sys;print(sys.executable)" 2>$null
        if ($exe) {
            $w = Join-Path (Split-Path $exe) 'pythonw.exe'
            if (Test-Path $w) { return $w }
        }
    }
    $c = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($c) {
        $w = Join-Path (Split-Path $c.Source) 'pythonw.exe'
        if (Test-Path $w) { return $w }
    }
    return $null
}

$pyw = Find-PythonW
if (-not $pyw) {
    Write-Host 'Не нашёл Python (pythonw.exe). Установите Python с python.org и поставьте галочку "Add to PATH".'
    exit 1
}

$name  = 'Видео-виджет drakeNier.lnk'
$shell = New-Object -ComObject WScript.Shell
$made  = @()
foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    if (-not $dir) { continue }
    $lnk = $shell.CreateShortcut((Join-Path $dir $name))
    $lnk.TargetPath       = $pyw
    $lnk.Arguments        = '"' + $app + '"'
    $lnk.WorkingDirectory = $root
    $lnk.IconLocation     = $icon + ',0'
    $lnk.Description      = 'Видео-виджет drakeNier'
    $lnk.Save()
    $made += $dir
}
Write-Host 'Готово! Ярлык создан:'
$made | ForEach-Object { Write-Host ('  ' + $_) }
Write-Host 'Он есть на рабочем столе и в меню Пуск (можно закрепить на панели задач).'
