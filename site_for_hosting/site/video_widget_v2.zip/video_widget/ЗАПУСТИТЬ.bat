@echo off
chcp 65001 >nul
title drakeNier widget

python -c "import vlc, PIL" 2>nul
if errorlevel 1 (
    echo Первый запуск: устанавливаю недостающие компоненты python-vlc и Pillow...
    python -m pip install --quiet python-vlc Pillow
)

if not exist "%~dp0data" mkdir "%~dp0data"
if not exist "%~dp0data\cv_tried.flag" (
    python -c "import cv2" 2>nul
    if errorlevel 1 (
        echo Один раз докачиваю компонент для обложек видео, это может занять минуту...
        python -m pip install --quiet opencv-python-headless
    )
    echo 1> "%~dp0data\cv_tried.flag"
)

where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "%~dp0app.py"
) else (
    start "" python "%~dp0app.py"
)
