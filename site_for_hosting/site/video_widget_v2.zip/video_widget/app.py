# -*- coding: utf-8 -*-
"""
Видео-виджет для рабочего стола (стиль NOT HUMAN)  —  версия 2
=================================================================
Всё, что было раньше, осталось:
  * плавающее окно поверх всех окон, видео со звуком из папки videos/;
  * новые файлы из videos/ сами появляются в плейлисте;
  * play/pause, предыдущее/следующее, стоп, перемотка, громкость;
  * когда видео заканчивается — включается следующее по кругу.

Что добавлено:
  * смена оформления: обои (готовые или свой файл), затемнение, цвет акцента;
  * вращающийся диск во время воспроизведения + можно поставить свою картинку;
  * окно меняет размер за любой край/угол, есть свернуть / развернуть;
  * запуск через ярлык как обычное приложение (значок на панели задач);
  * плейлист: строки перетаскиваются мышкой (порядок запоминается),
    у каждого видео видна обложка (кадр из видео или своя картинка).

Зависимости:  pip install python-vlc Pillow   (+ установленный VLC media player)
Необязательно: pip install opencv-python-headless  — тогда обложки для всех видео
делаются сразу, а не только после первого запуска каждого ролика.
"""

import os
import sys
import json
import math
import time
import queue
import random
import shutil
import hashlib
import threading
import subprocess
import traceback
import tkinter as tk
from tkinter import font as tkfont, filedialog, colorchooser, messagebox

IS_WIN = sys.platform.startswith("win")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VIDEOS_DIR = os.path.join(BASE_DIR, "videos")
DATA_DIR = os.path.join(BASE_DIR, "data")
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
COVERS_DIR = os.path.join(DATA_DIR, "covers")
SETTINGS_PATH = os.path.join(DATA_DIR, "settings.json")
for _d in (VIDEOS_DIR, DATA_DIR, COVERS_DIR):
    os.makedirs(_d, exist_ok=True)


def _die(message):
    """Сообщение об ошибке, которое видно и без консоли (pythonw)."""
    try:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("drakeNier widget", message)
        root.destroy()
    except Exception:
        print(message)
    sys.exit(1)


try:
    import vlc
except ImportError:
    _die("Не найден пакет python-vlc.\nУстановите его командой:\n    pip install python-vlc")

try:
    from PIL import Image, ImageTk, ImageDraw, ImageFilter, ImageChops, ImageStat
except ImportError:
    _die("Не найден пакет Pillow (нужен для диска, обоев и обложек).\n"
         "Установите его командой:\n    pip install Pillow")

RS = getattr(Image, "Resampling", Image)  # совместимость со старыми Pillow

# ---------------------------------------------------------------------------
# Настройки
# ---------------------------------------------------------------------------

DEFAULT_ACCENT = "#39FF14"
FONT_NAME = "Consolas"
VIDEO_EXTENSIONS = {".mp4", ".mkv", ".avi", ".mov", ".webm", ".m4v", ".wmv"}
POLL_INTERVAL_MS = 2000

HEAD_H = 34
MIN_W, MIN_H = 360, 260
EDGE = 6
CORNER = 10

ACCENT_CHOICES = ["#39FF14", "#00E5FF", "#FF3CAC", "#B26BFF", "#FF9F1C", "#FF4D4D", "#E8E8E8"]

PRESET_WALLPAPERS = [
    ("grid", "Неон-сетка"),
    ("dark", "Тёмный"),
    ("sunset", "Закат"),
    ("aurora", "Аврора"),
    ("sakura", "Сакура"),
]


def is_video_file(filename):
    return os.path.splitext(filename)[1].lower() in VIDEO_EXTENSIONS


def scan_videos():
    try:
        return [f for f in os.listdir(VIDEOS_DIR) if is_video_file(f)]
    except FileNotFoundError:
        return []


class Settings:
    DEFAULTS = {
        "accent": DEFAULT_ACCENT,
        "wallpaper": {"kind": "preset", "value": "grid"},
        "dim": 0.25,
        "disc": "default",
        "disc_speed": 120,
        "volume": 80,
        "topmost": True,
        "show_playlist": True,
        "geometry": None,
        "order": [],
        "covers": {},
    }

    def __init__(self, path):
        self.path = path
        self.data = json.loads(json.dumps(self.DEFAULTS))
        try:
            with open(path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            if isinstance(loaded, dict):
                self.data.update(loaded)
        except Exception:
            pass

    def get(self, key):
        return self.data.get(key, self.DEFAULTS.get(key))

    def set(self, key, value):
        self.data[key] = value

    def save(self):
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Цвета и вспомогательные функции
# ---------------------------------------------------------------------------

def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in rgb)


def shade(h, k):
    r, g, b = hex_rgb(h)
    return rgb_hex((r * k, g * k, b * k))


def make_colors(accent):
    return {
        "accent": accent,
        "bg": shade(accent, 0.05),
        "band": shade(accent, 0.04),
        "panel": shade(accent, 0.08),
        "btn": shade(accent, 0.14),
        "btn_hover": shade(accent, 0.34),
        "sel": shade(accent, 0.22),
        "track": shade(accent, 0.26),
        "dim": shade(accent, 0.5),
        "text": shade(accent, 0.85),
    }


def fmt_time(ms):
    if not ms or ms < 0:
        ms = 0
    s = int(ms // 1000)
    return "%02d:%02d" % (s // 60, s % 60)


def fit_text(font, text, maxw, lines=1):
    """Режет текст по ширине в пикселях (до lines строк, последняя — с «…»)."""
    if maxw <= 10 or not text:
        return ""
    out = []
    rest = text
    for li in range(lines):
        last = li == lines - 1
        if font.measure(rest) <= maxw:
            out.append(rest)
            rest = ""
            break
        lo, hi = 1, len(rest)
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if font.measure(rest[:mid]) <= maxw:
                lo = mid
            else:
                hi = mid - 1
        if last:
            n = lo
            while n > 1 and font.measure(rest[:n] + "…") > maxw:
                n -= 1
            out.append(rest[:n] + "…")
            rest = ""
        else:
            out.append(rest[:lo])
            rest = rest[lo:]
    return "\n".join(out)


def work_area(root):
    if IS_WIN:
        try:
            import ctypes
            from ctypes import wintypes
            rect = wintypes.RECT()
            ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0)
            return rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top
        except Exception:
            pass
    return 0, 0, root.winfo_screenwidth(), root.winfo_screenheight()


# ---------------------------------------------------------------------------
# Обои: готовые заготовки (рисуются кодом, отдельных файлов не нужно)
# ---------------------------------------------------------------------------

def _vgrad(w, h, stops):
    col = Image.new("RGB", (1, h))
    px = col.load()
    for y in range(h):
        t = y / max(1, h - 1)
        for j in range(len(stops) - 1):
            p0, c0 = stops[j]
            p1, c1 = stops[j + 1]
            if t <= p1 or j == len(stops) - 2:
                f = 0.0 if p1 == p0 else min(1.0, max(0.0, (t - p0) / (p1 - p0)))
                px[0, y] = tuple(int(c0[i] + (c1[i] - c0[i]) * f) for i in range(3))
                break
    return col.resize((w, h), RS.BILINEAR)


def make_preset(name, accent):
    ar = hex_rgb(accent)

    def sh(k):
        return tuple(int(v * k) for v in ar)

    if name == "dark":
        return _vgrad(960, 540, [(0, sh(0.16)), (0.6, (6, 8, 7)), (1, (2, 3, 3))])

    if name == "grid":
        W, H = 1280, 720
        hz = int(H * 0.42)
        img = _vgrad(W, H, [(0, (2, 3, 4)), (0.42, sh(0.24)), (0.4201, (2, 3, 3)), (1, (3, 5, 4))])
        lay = Image.new("RGB", (W, H), (0, 0, 0))
        d = ImageDraw.Draw(lay)
        for k in range(-26, 27):
            d.line([(W / 2 + k * 9, hz), (W / 2 + k * 120, H)], fill=ar, width=2)
        for i in range(1, 17):
            y = hz + (H - hz) * ((i / 16.0) ** 2.2)
            d.line([(0, y), (W, y)], fill=ar, width=2)
        glow = lay.filter(ImageFilter.GaussianBlur(3))
        lay = ImageChops.add(lay, glow)
        lay = ImageChops.multiply(lay, Image.new("RGB", (W, H), (150, 150, 150)))
        return ImageChops.add(img, lay)

    if name == "sunset":
        W, H = 640, 360
        img = _vgrad(W, H, [(0, (24, 8, 48)), (0.45, (150, 40, 100)), (0.62, (255, 110, 90)),
                            (0.7, (255, 180, 110)), (1, (20, 8, 30))])
        d = ImageDraw.Draw(img)
        d.ellipse((W // 2 - 70, int(H * 0.58) - 70, W // 2 + 70, int(H * 0.58) + 70), fill=(255, 225, 160))
        rnd = random.Random(7)
        hz = int(H * 0.7)
        x = 0
        while x < W:
            bw = rnd.randint(14, 40)
            bh = rnd.randint(10, 70)
            d.rectangle((x, hz - bh, x + bw, hz), fill=(14, 6, 22))
            x += bw + rnd.randint(0, 4)
        d.rectangle((0, hz, W, H), fill=(14, 6, 22))
        return img.resize((1280, 720), RS.BICUBIC)

    if name == "aurora":
        W, H = 320, 180
        base = Image.new("RGB", (W, H), (3, 6, 10))
        blobs = [(ar, (20, 70, 200, 110)), ((0, 200, 255), (110, 20, 300, 90)),
                 ((150, 60, 255), (-20, 100, 180, 170))]
        for color, box in blobs:
            mask = Image.new("L", (W, H), 0)
            ImageDraw.Draw(mask).ellipse(box, fill=170)
            mask = mask.filter(ImageFilter.GaussianBlur(26))
            base = Image.composite(Image.new("RGB", (W, H), color), base, mask)
        return base.resize((1280, 720), RS.BICUBIC)

    # sakura
    W, H = 320, 180
    img = _vgrad(W, H, [(0, (70, 30, 70)), (1, (255, 170, 200))])
    d = ImageDraw.Draw(img)
    rnd = random.Random(11)
    for _ in range(45):
        x, y, r = rnd.randint(0, W), rnd.randint(0, H), rnd.randint(2, 7)
        d.ellipse((x - r, y - r, x + r, y + r), fill=(255, 232, 240))
    img = img.filter(ImageFilter.GaussianBlur(1.4))
    return img.resize((1280, 720), RS.BICUBIC)


# ---------------------------------------------------------------------------
# Диск
# ---------------------------------------------------------------------------

def process_disc_image(img, size=512):
    """Любую картинку превращает в круглый диск (RGBA, size x size).
    Если у картинки уже прозрачные углы (как у вашего диска) — просто обрезаем по краям."""
    img = img.convert("RGBA")
    w, h = img.size
    alpha = img.getchannel("A")
    corners = [alpha.getpixel(p) for p in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1))]
    bbox = alpha.getbbox()
    if max(corners) < 40 and bbox is not None:
        img = img.crop(bbox)
        s = max(img.size)
        sq = Image.new("RGBA", (s, s), (0, 0, 0, 0))
        sq.paste(img, ((s - img.width) // 2, (s - img.height) // 2))
        return sq.resize((size, size), RS.LANCZOS)

    s = min(w, h)
    left, top = (w - s) // 2, (h - s) // 2
    S = size * 2
    img = img.crop((left, top, left + s, top + s)).resize((S, S), RS.LANCZOS)
    c = S // 2
    hole = int(S * 0.07)
    ring_r = int(S * 0.15)
    ring = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring)
    rd.ellipse((c - ring_r, c - ring_r, c + ring_r, c + ring_r), fill=(235, 235, 235, 150))
    img = Image.alpha_composite(img, ring)
    mask = Image.new("L", (S, S), 0)
    md = ImageDraw.Draw(mask)
    md.ellipse((0, 0, S - 1, S - 1), fill=255)
    md.ellipse((c - hole, c - hole, c + hole, c + hole), fill=0)
    img.putalpha(mask)
    return img.resize((size, size), RS.LANCZOS)


def fallback_disc(accent=DEFAULT_ACCENT, size=512):
    S = size * 2
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((0, 0, S - 1, S - 1), fill=hex_rgb(shade(accent, 0.5)) + (255,))
    d.ellipse((S * 0.30, S * 0.30, S * 0.70, S * 0.70), fill=hex_rgb(accent) + (255,))
    d.ellipse((S * 0.46, S * 0.46, S * 0.54, S * 0.54), fill=(0, 0, 0, 0))
    return img.resize((size, size), RS.LANCZOS)


# ---------------------------------------------------------------------------
# Обложки видео
# ---------------------------------------------------------------------------

class CoverManager:
    IMG_EXT = (".jpg", ".jpeg", ".png", ".webp")

    def __init__(self, settings):
        self.s = settings
        self.q_in = queue.Queue()
        self.q_out = queue.Queue()
        self.pending = set()
        self.failed = set()
        threading.Thread(target=self._worker, daemon=True).start()

    # --- пути
    def _vpath(self, name):
        return os.path.join(VIDEOS_DIR, name)

    def _key(self, name):
        try:
            st = os.stat(self._vpath(name))
            raw = "%s|%d|%d" % (name, st.st_size, int(st.st_mtime))
        except OSError:
            raw = name
        return hashlib.md5(raw.encode("utf-8")).hexdigest()[:16]

    def cache_path(self, name):
        return os.path.join(COVERS_DIR, self._key(name) + ".jpg")

    def cover_for(self, name, request=True):
        custom = (self.s.get("covers") or {}).get(name)
        if custom and os.path.exists(custom):
            return custom
        base = os.path.splitext(name)[0]
        for ext in self.IMG_EXT:
            p = os.path.join(VIDEOS_DIR, base + ext)
            if os.path.exists(p):
                return p
        p = self.cache_path(name)
        if os.path.exists(p):
            return p
        if request and name not in self.pending and name not in self.failed:
            self.pending.add(name)
            self.q_in.put(name)
        return None

    # --- ручные обложки
    def set_custom(self, name, image_path):
        img = Image.open(image_path).convert("RGB")
        img.thumbnail((400, 400), RS.LANCZOS)
        dst = os.path.join(COVERS_DIR, "custom_" + self._key(name) + ".jpg")
        img.save(dst, "JPEG", quality=88)
        covers = dict(self.s.get("covers") or {})
        covers[name] = dst
        self.s.set("covers", covers)
        self.s.save()

    def clear_custom(self, name):
        covers = dict(self.s.get("covers") or {})
        path = covers.pop(name, None)
        self.s.set("covers", covers)
        self.s.save()
        if path and os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass

    def adopt(self, name, path):
        """Сохранить снимок (например, от VLC) как обложку."""
        img = Image.open(path).convert("RGB")
        img.thumbnail((320, 320), RS.LANCZOS)
        img.save(self.cache_path(name), "JPEG", quality=85)
        self.failed.discard(name)

    # --- фоновое создание обложек
    def drain(self):
        got = False
        while True:
            try:
                self.q_out.get_nowait()
                got = True
            except queue.Empty:
                return got

    def _worker(self):
        while True:
            name = self.q_in.get()
            ok = False
            try:
                ok = self._make(name)
            except Exception:
                ok = False
            self.pending.discard(name)
            if not ok:
                self.failed.add(name)
            self.q_out.put((name, ok))

    def _make(self, name):
        src = self._vpath(name)
        img = self._grab_cv2(src) or self._grab_ffmpeg(src, name)
        if img is None:
            return False
        img.thumbnail((320, 320), RS.LANCZOS)
        img.convert("RGB").save(self.cache_path(name), "JPEG", quality=85)
        return True

    @staticmethod
    def _grab_cv2(src):
        try:
            import cv2
        except Exception:
            return None
        cap = cv2.VideoCapture(src)
        try:
            if not cap.isOpened():
                return None
            total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
            for frac in (0.1, 0.3, 0.5, 0.0):
                if total > 0:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, int(total * frac))
                ok, frame = cap.read()
                if not ok or frame is None:
                    continue
                img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                if ImageStat.Stat(img.convert("L")).mean[0] > 10 or frac == 0.0:
                    return img
            return None
        except Exception:
            return None
        finally:
            cap.release()

    def _grab_ffmpeg(self, src, name):
        exe = shutil.which("ffmpeg")
        local = os.path.join(BASE_DIR, "ffmpeg.exe")
        if not exe and os.path.exists(local):
            exe = local
        if not exe:
            return None
        tmp = os.path.join(COVERS_DIR, "_tmp_" + self._key(name) + ".jpg")
        flags = 0x08000000 if IS_WIN else 0  # CREATE_NO_WINDOW
        for ss in ("5", "1", "0"):
            try:
                subprocess.run([exe, "-y", "-v", "error", "-ss", ss, "-i", src, "-frames:v", "1",
                                "-vf", "scale=320:-2", tmp], timeout=25, creationflags=flags,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if os.path.exists(tmp):
                    img = Image.open(tmp).convert("RGB")
                    img.load()
                    os.remove(tmp)
                    return img
            except Exception:
                continue
        return None


# ---------------------------------------------------------------------------
# Плейлист с обложками и перетаскиванием
# ---------------------------------------------------------------------------

class PlaylistView(tk.Frame):
    ROW_H = 56
    TW, TH = 80, 45

    def __init__(self, master, app):
        c = app.c
        super().__init__(master, bg=c["panel"], highlightthickness=1,
                         highlightbackground=c["accent"], highlightcolor=c["accent"])
        self.app = app
        self.items = []
        self.current = None
        self.scroll = 0
        self.hover = None
        self.press = None
        self.dragging = False
        self.drag_i = None
        self.drag_y = 0
        self.cache = {}

        self.title_lbl = tk.Label(self, text="ПЛЕЙЛИСТ", bg=c["panel"], fg=c["accent"], font=app.f_small)
        self.title_lbl.pack(side="top", pady=(6, 2))
        self.hint = tk.Label(self, text="Тяните строки мышкой —\nменяется порядок видео",
                             bg=c["panel"], fg=c["dim"], font=app.f_tiny, justify="center")
        self.hint.pack(side="bottom", pady=6)
        self.cv = tk.Canvas(self, bg=c["bg"], highlightthickness=0, bd=0)
        self.cv.pack(side="top", fill="both", expand=True, padx=4, pady=2)

        cv = self.cv
        cv.bind("<Configure>", lambda e: self.redraw())
        cv.bind("<ButtonPress-1>", self._on_press)
        cv.bind("<B1-Motion>", self._on_motion_drag)
        cv.bind("<ButtonRelease-1>", self._on_release)
        cv.bind("<Motion>", self._on_hover)
        cv.bind("<Leave>", self._on_leave)
        cv.bind("<Button-3>", self._on_menu)
        cv.bind("<Enter>", lambda e: cv.focus_set())
        cv.bind("<MouseWheel>", self._on_wheel)
        cv.bind("<Button-4>", lambda e: self._scroll_by(-self.ROW_H))
        cv.bind("<Button-5>", lambda e: self._scroll_by(self.ROW_H))

    # ---- внешний интерфейс
    def recolor(self):
        c = self.app.c
        self.configure(bg=c["panel"], highlightbackground=c["accent"], highlightcolor=c["accent"])
        self.title_lbl.configure(bg=c["panel"], fg=c["accent"])
        self.hint.configure(bg=c["panel"], fg=c["dim"])
        self.cv.configure(bg=c["bg"])
        self.redraw()

    def set_items(self, items):
        self.items = list(items)
        self.cache.clear()
        self.redraw()

    def set_current(self, index):
        self.current = index
        if index is not None and self.items:
            h = self.cv.winfo_height()
            top = index * self.ROW_H
            if top < self.scroll:
                self.scroll = top
            elif top + self.ROW_H > self.scroll + h:
                self.scroll = top + self.ROW_H - h
        self.redraw()

    def clear_cache(self):
        self.cache.clear()
        self.redraw()

    # ---- рисование
    def _max_scroll(self):
        return max(0, len(self.items) * self.ROW_H - self.cv.winfo_height())

    def _scroll_by(self, dy):
        self.scroll = max(0, min(self._max_scroll(), self.scroll + dy))
        self.redraw()

    def _thumb(self, name):
        if name in self.cache:
            return self.cache[name]
        photo = False
        path = self.app.covers.cover_for(name)
        if path:
            try:
                img = Image.open(path).convert("RGB")
                sw, sh = img.size
                scale = max(self.TW / sw, self.TH / sh)
                nw, nh = max(1, int(sw * scale + 0.5)), max(1, int(sh * scale + 0.5))
                img = img.resize((nw, nh), RS.BILINEAR)
                l, t = (nw - self.TW) // 2, (nh - self.TH) // 2
                photo = ImageTk.PhotoImage(img.crop((l, t, l + self.TW, t + self.TH)))
            except Exception:
                photo = False
        self.cache[name] = photo
        return photo

    def _draw_row(self, i, y, mode="normal"):
        cv, c = self.cv, self.app.c
        w = cv.winfo_width()
        name = self.items[i]
        is_cur = (i == self.current)
        if mode == "ghost":
            fill, outline = c["sel"], c["accent"]
        elif mode == "dim":
            fill, outline = c["bg"], c["track"]
        elif is_cur:
            fill, outline = c["sel"], c["accent"]
        elif i == self.hover and not self.dragging:
            fill, outline = c["btn"], c["track"]
        else:
            fill, outline = c["bg"], ""
        cv.create_rectangle(1, y + 1, w - 1, y + self.ROW_H - 1, fill=fill, outline=outline)
        tx, ty = 6, y + (self.ROW_H - self.TH) // 2
        photo = self._thumb(name)
        if photo:
            cv.create_image(tx, ty, image=photo, anchor="nw")
            cv.create_rectangle(tx, ty, tx + self.TW, ty + self.TH, outline=c["track"])
        else:
            cv.create_rectangle(tx, ty, tx + self.TW, ty + self.TH, fill=c["panel"], outline=c["track"])
            cx, cy = tx + self.TW // 2, ty + self.TH // 2
            cv.create_polygon(cx - 7, cy - 9, cx - 7, cy + 9, cx + 9, cy, fill=c["dim"], outline="")
        if is_cur and mode != "dim":
            cv.create_polygon(tx + 4, ty + self.TH - 14, tx + 4, ty + self.TH - 4, tx + 14, ty + self.TH - 9,
                              fill=c["accent"], outline="")
        textx = tx + self.TW + 8
        maxw = w - textx - 18
        label = fit_text(self.app.f_small, os.path.splitext(name)[0], maxw, lines=2)
        cv.create_text(textx, y + self.ROW_H // 2, text=label, anchor="w",
                       fill=c["accent"] if is_cur else c["text"], font=self.app.f_small)
        gx = w - 11
        for k in (-4, 0, 4):
            cv.create_line(gx - 3, y + self.ROW_H // 2 + k, gx + 3, y + self.ROW_H // 2 + k, fill=c["dim"])

    def redraw(self):
        cv = self.cv
        cv.delete("all")
        w, h = cv.winfo_width(), cv.winfo_height()
        if w < 20 or h < 20:
            return
        self.scroll = max(0, min(self._max_scroll(), self.scroll))
        n = len(self.items)
        if n == 0:
            cv.create_text(w // 2, h // 2, text="Пусто.\nПоложите видео\nв папку videos",
                           fill=self.app.c["dim"], font=self.app.f_small, justify="center")
            return
        first = max(0, int(self.scroll // self.ROW_H))
        last = min(n - 1, int((self.scroll + h) // self.ROW_H))
        for i in range(first, last + 1):
            y = i * self.ROW_H - self.scroll
            mode = "dim" if (self.dragging and i == self.drag_i) else "normal"
            self._draw_row(i, y, mode)
        if self.dragging:
            slot = self._slot()
            ly = slot * self.ROW_H - self.scroll
            cv.create_line(2, ly, w - 2, ly, fill=self.app.c["accent"], width=3)
            gy = max(0, min(h - self.ROW_H, self.drag_y - self.ROW_H // 2))
            self._draw_row(self.drag_i, gy, "ghost")
        content = n * self.ROW_H
        if content > h:
            th = max(24, h * h / content)
            ty = (h - th) * (self.scroll / max(1, content - h))
            cv.create_rectangle(w - 4, ty, w - 1, ty + th, fill=self.app.c["track"], outline="")

    # ---- мышь
    def _row_at(self, y):
        i = int((y + self.scroll) // self.ROW_H)
        return i if 0 <= i < len(self.items) else None

    def _slot(self):
        s = int((self.drag_y + self.scroll) / self.ROW_H + 0.5)
        return max(0, min(len(self.items), s))

    def _on_press(self, e):
        i = self._row_at(e.y)
        self.press = (i, e.x, e.y) if i is not None else None
        self.dragging = False

    def _on_motion_drag(self, e):
        if not self.press:
            return
        i, px, py = self.press
        if not self.dragging and (abs(e.y - py) > 5 or abs(e.x - px) > 5):
            self.dragging = True
            self.drag_i = i
            self.cv.configure(cursor="fleur")
            self._autoscroll()
        if self.dragging:
            self.drag_y = e.y
            self.redraw()

    def _autoscroll(self):
        if not self.dragging:
            return
        h = self.cv.winfo_height()
        if self.drag_y < 22:
            self._scroll_by(-10)
        elif self.drag_y > h - 22:
            self._scroll_by(10)
        self.after(40, self._autoscroll)

    def _on_release(self, e):
        if not self.press:
            return
        i = self.press[0]
        was_drag = self.dragging
        slot = self._slot() if was_drag else None
        self.press = None
        self.dragging = False
        self.cv.configure(cursor="")
        if was_drag:
            new = slot if slot <= i else slot - 1
            if new != i:
                self.app.on_reorder(i, new)
            else:
                self.redraw()
        else:
            self.app.play_index(i)

    def _on_hover(self, e):
        h = self._row_at(e.y)
        if h != self.hover:
            self.hover = h
            self.redraw()

    def _on_leave(self, e):
        if self.hover is not None:
            self.hover = None
            self.redraw()

    def _on_wheel(self, e):
        self._scroll_by(-int(e.delta / 120 * self.ROW_H * 0.8) if e.delta else 0)

    def _on_menu(self, e):
        c = self.app.c
        i = self._row_at(e.y)
        m = tk.Menu(self, tearoff=0, bg=c["panel"], fg=c["accent"],
                    activebackground=c["btn_hover"], activeforeground=c["accent"])
        if i is not None:
            name = self.items[i]
            m.add_command(label="Задать обложку…", command=lambda: self.app.choose_cover(name))
            m.add_command(label="Сбросить обложку", command=lambda: self.app.reset_cover(name))
            m.add_separator()
        m.add_command(label="Открыть папку videos", command=self.app.open_videos_folder)
        try:
            m.tk_popup(e.x_root, e.y_root)
        finally:
            m.grab_release()


# ---------------------------------------------------------------------------
# Окно «Оформление»
# ---------------------------------------------------------------------------

class SettingsDialog(tk.Toplevel):
    BG = "#101410"
    FG = "#d8e0d8"

    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.title("Оформление")
        self.configure(bg=self.BG)
        self.resizable(False, False)
        self.attributes("-topmost", True)
        self.geometry("+%d+%d" % (app.winfo_x() + 40, app.winfo_y() + 40))
        self.protocol("WM_DELETE_WINDOW", self.close)
        self._building = False
        self._preview = None
        self.build()

    def close(self):
        self.app._dialog = None
        self.destroy()

    def _button(self, parent, text, cmd):
        a = self.app.accent
        return tk.Button(parent, text=text, command=cmd, bg=shade(a, 0.16), fg=a,
                         activebackground=shade(a, 0.38), activeforeground=a, relief="flat",
                         bd=0, padx=10, pady=4, font=self.app.f_small, cursor="hand2")

    def _label(self, parent, text, head=False):
        return tk.Label(parent, text=text, bg=self.BG, fg=self.app.accent if head else self.FG,
                        font=self.app.f_title if head else self.app.f_small, anchor="w")

    def _scale(self, parent, lo, hi, value, cmd, length=260):
        a = self.app.accent
        sc = tk.Scale(parent, from_=lo, to=hi, orient="horizontal", showvalue=True, length=length,
                      bg=self.BG, fg=self.FG, troughcolor=shade(a, 0.22), highlightthickness=0, bd=0,
                      activebackground=a, font=self.app.f_small,
                      command=lambda v: None if self._building else cmd(float(v)))
        sc.set(value)
        return sc

    def build(self):
        self._building = True
        for w in self.winfo_children():
            w.destroy()
        app, a = self.app, self.app.accent
        pad = {"padx": 14}

        self._label(self, "ОБОИ", head=True).pack(fill="x", pady=(12, 4), **pad)
        row = tk.Frame(self, bg=self.BG)
        row.pack(fill="x", **pad)
        for i, (key, label) in enumerate(PRESET_WALLPAPERS):
            self._button(row, label, lambda k=key: app.set_wallpaper("preset", k)).grid(
                row=i // 3, column=i % 3, padx=3, pady=3, sticky="ew")
        self._button(row, "Свой файл…", self.pick_wallpaper).grid(row=1, column=2, padx=3, pady=3, sticky="ew")
        self._label(self, "Затемнение обоев, %").pack(fill="x", pady=(8, 0), **pad)
        self._scale(self, 0, 90, int(app.dim * 100), lambda v: app.set_dim(v / 100.0)).pack(**pad)

        self._label(self, "ЦВЕТ ОФОРМЛЕНИЯ", head=True).pack(fill="x", pady=(12, 4), **pad)
        sw = tk.Frame(self, bg=self.BG)
        sw.pack(fill="x", **pad)
        for col in ACCENT_CHOICES:
            b = tk.Frame(sw, bg=col, width=28, height=28, cursor="hand2",
                         highlightthickness=2, highlightbackground=("#ffffff" if col.lower() == a.lower() else self.BG))
            b.pack(side="left", padx=3)
            b.bind("<Button-1>", lambda e, c=col: self.pick_color(c))
        self._button(sw, "Свой…", lambda: self.pick_color(None)).pack(side="left", padx=8)

        self._label(self, "ДИСК", head=True).pack(fill="x", pady=(12, 4), **pad)
        drow = tk.Frame(self, bg=self.BG)
        drow.pack(fill="x", **pad)
        pv = tk.Canvas(drow, width=96, height=96, bg=self.BG, highlightthickness=0)
        pv.pack(side="left")
        try:
            self._preview = ImageTk.PhotoImage(app.disc_base.resize((90, 90), RS.LANCZOS))
            pv.create_image(48, 48, image=self._preview)
        except Exception:
            pass
        col = tk.Frame(drow, bg=self.BG)
        col.pack(side="left", padx=12)
        self._button(col, "Выбрать картинку…", self.pick_disc).pack(fill="x", pady=2)
        self._button(col, "Вернуть стандартный", self.reset_disc).pack(fill="x", pady=2)
        self._label(self, "Скорость вращения").pack(fill="x", pady=(8, 0), **pad)
        self._scale(self, 30, 360, int(app.disc_speed), lambda v: app.set_speed(v)).pack(**pad)

        self._button(self, "Готово", self.close).pack(pady=14)
        self._building = False

    def pick_wallpaper(self):
        path = filedialog.askopenfilename(
            parent=self, title="Выберите картинку для обоев",
            filetypes=[("Изображения", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("Все файлы", "*.*")])
        if path:
            self.app.set_wallpaper("file", path)

    def pick_color(self, col):
        if col is None:
            res = colorchooser.askcolor(color=self.app.accent, parent=self, title="Цвет оформления")
            col = res[1] if res else None
        if col:
            self.app.set_accent(col)
            self.build()

    def pick_disc(self):
        path = filedialog.askopenfilename(
            parent=self, title="Выберите картинку для диска",
            filetypes=[("Изображения", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("Все файлы", "*.*")])
        if path and self.app.set_disc_file(path):
            self.build()

    def reset_disc(self):
        self.app.reset_disc()
        self.build()


# ---------------------------------------------------------------------------
# Главное окно
# ---------------------------------------------------------------------------

class VideoWidget(tk.Tk):
    def __init__(self):
        super().__init__()
        self.settings = Settings(SETTINGS_PATH)
        s = self.settings
        self.accent = s.get("accent") or DEFAULT_ACCENT
        self.c = make_colors(self.accent)
        self.dim = float(s.get("dim") or 0)
        self.disc_speed = float(s.get("disc_speed") or 120)
        self.topmost = bool(s.get("topmost"))
        self.show_playlist = bool(s.get("show_playlist"))

        self.title("drakeNier widget")
        self.configure(bg="#000000")
        self._set_icon()

        self.f_title = tkfont.Font(family=FONT_NAME, size=11, weight="bold")
        self.f_small = tkfont.Font(family=FONT_NAME, size=9)
        self.f_tiny = tkfont.Font(family=FONT_NAME, size=8)
        self.f_sym = tkfont.Font(family=("Segoe UI Symbol" if IS_WIN else "DejaVu Sans"), size=13)

        self._init_geometry()

        # состояние
        self.playlist = []
        self.current_index = None
        self.is_playing = False
        self.now_text = "— нет видео —"
        self.regions = []
        self.btn_style = {}
        self.sl = {"seek": {"x0": 0, "x1": 1, "y": 0, "frac": 0.0},
                   "vol": {"x0": 0, "x1": 1, "y": 0, "frac": max(0, min(100, int(s.get("volume") or 80))) / 100.0}}
        self._hover = None
        self._cursor = ""
        self._mode = None
        self._active = None
        self._rs = None
        self._drag_x = self._drag_y = 0
        self._seeking = False
        self._ended = False
        self._maxed = False
        self._minimized = False
        self._normal_rect = None
        self._saved_geo = None
        self._layout_job = None
        self._probe_token = 0
        self._vol_applied = False
        self._dialog = None
        self._play_pos = (0, 0, 8)
        self._title_maxw = 100
        self._bg_photo = None
        self._disc_photo = None
        self.angle = 0.0
        self.vel = 0.0
        self._last_t = time.time()
        self.disc_d = 0
        self.disc_src = None
        self.disc_base = None
        self.wp_src = None

        # холст на всё окно: обои + рисованные элементы
        self.canvas = tk.Canvas(self, bg=self.c["bg"], highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_image(0, 0, anchor="nw", tags="bg")

        self.video_frame = tk.Frame(self, bg="black", highlightthickness=1,
                                    highlightbackground=self.accent, highlightcolor=self.accent)
        self.playlist_view = PlaylistView(self, self)
        self.covers = CoverManager(self.settings)

        self._load_disc()
        self._load_wallpaper()

        # VLC
        self.vlc_instance = vlc.Instance("--quiet")
        self.player = self.vlc_instance.media_player_new()
        try:
            self.player.video_set_mouse_input(False)
            self.player.video_set_key_input(False)
        except Exception:
            pass
        events = self.player.event_manager()
        events.event_attach(vlc.EventType.MediaPlayerEndReached, self._on_video_end)

        # события мыши и клавиатуры
        cv = self.canvas
        cv.bind("<ButtonPress-1>", self._on_press)
        cv.bind("<B1-Motion>", self._on_drag)
        cv.bind("<ButtonRelease-1>", self._on_release)
        cv.bind("<Motion>", self._on_motion)
        cv.bind("<Leave>", lambda e: self._set_hover(None))
        cv.bind("<Double-Button-1>", self._on_double)
        cv.bind("<Configure>", lambda e: self._schedule_layout())
        self.bind("<space>", lambda e: self.toggle_play())
        self.bind("<Left>", lambda e: self.seek_relative(-10000))
        self.bind("<Right>", lambda e: self.seek_relative(10000))
        self.protocol("WM_DELETE_WINDOW", self.close_app)

        # окно без системной рамки, но с кнопкой на панели задач
        self.overrideredirect(True)
        self.attributes("-topmost", self.topmost)

        self.update_idletasks()
        self._relayout()
        self._embed_player()
        self.after(150, self._apply_appwindow)

        self.playlist = self._merge_order(scan_videos())
        self.settings.set("order", list(self.playlist))
        self.playlist_view.set_items(self.playlist)
        if self.playlist:
            self.play_index(0)
        self._apply_volume()

        self.after(POLL_INTERVAL_MS, self._poll_folder)
        self.after(300, self._tick)
        self.after(500, self._poll_covers)
        self.after(33, self._anim)

    # ------------------------------------------------------------ старт

    def _set_icon(self):
        ico = os.path.join(ASSETS_DIR, "icon.ico")
        png = os.path.join(ASSETS_DIR, "icon.png")
        try:
            if IS_WIN and os.path.exists(ico):
                self.iconbitmap(default=ico)
            elif os.path.exists(png):
                self._icon_img = ImageTk.PhotoImage(Image.open(png))
                self.iconphoto(True, self._icon_img)
        except Exception:
            pass

    def _init_geometry(self):
        g = self.settings.get("geometry") or {}
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        try:
            w = max(MIN_W, min(sw, int(g.get("w", 720))))
            h = max(MIN_H, min(sh, int(g.get("h", 460))))
            x = int(g.get("x", 80))
            y = int(g.get("y", 80))
        except Exception:
            w, h, x, y = 720, 460, 80, 80
        x = max(-w + 120, min(sw - 120, x))
        y = max(0, min(sh - 60, y))
        self.geometry("%dx%d+%d+%d" % (w, h, x, y))

    def _load_disc(self):
        path = None
        if self.settings.get("disc") == "custom":
            p = os.path.join(DATA_DIR, "disc_custom.png")
            if os.path.exists(p):
                path = p
        if not path:
            path = os.path.join(ASSETS_DIR, "disc_default.png")
        try:
            self.disc_base = process_disc_image(Image.open(path))
        except Exception:
            self.disc_base = fallback_disc(self.accent)

    def _load_wallpaper(self):
        wp = self.settings.get("wallpaper") or {}
        img = None
        try:
            if wp.get("kind") == "file" and wp.get("value") and os.path.exists(wp["value"]):
                img = Image.open(wp["value"]).convert("RGB")
                img.thumbnail((1920, 1920), RS.LANCZOS)
            else:
                img = make_preset(wp.get("value") or "grid", self.accent)
        except Exception:
            img = None
        if img is None:
            try:
                img = make_preset("grid", self.accent)
            except Exception:
                img = Image.new("RGB", (64, 64), hex_rgb(self.c["bg"]))
        self.wp_src = img

    def _embed_player(self):
        self.update_idletasks()
        handle = self.video_frame.winfo_id()
        if IS_WIN:
            self.player.set_hwnd(handle)
        elif sys.platform.startswith("linux"):
            self.player.set_xwindow(handle)
        elif sys.platform == "darwin":
            self.player.set_nsobject(handle)

    def _apply_appwindow(self):
        """Окно без рамки получает кнопку на панели задач, как обычное приложение."""
        if not IS_WIN:
            return
        try:
            import ctypes
            GWL_EXSTYLE, WS_EX_APPWINDOW, WS_EX_TOOLWINDOW = -20, 0x00040000, 0x00000080
            user32 = ctypes.windll.user32
            hwnd = user32.GetParent(self.winfo_id())
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, (style & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW)
            self.withdraw()
            self.after(40, self._after_appwindow)
        except Exception:
            pass

    def _after_appwindow(self):
        self.deiconify()
        self.attributes("-topmost", self.topmost)
        self.after(60, self._embed_player)

    # ------------------------------------------------------------ раскладка

    def _schedule_layout(self):
        if self._layout_job is None:
            self._layout_job = self.after_idle(self._relayout)

    def _render_bg(self, W, H, ctrl_y):
        src = self.wp_src
        sw, sh = src.size
        sc = max(W / sw, H / sh)
        nw, nh = max(W, int(sw * sc + 0.5)), max(H, int(sh * sc + 0.5))
        l, t = (nw - W) // 2, (nh - H) // 2
        img = src.resize((nw, nh), RS.BILINEAR).crop((l, t, l + W, t + H))
        if self.dim > 0:
            img = Image.blend(img, Image.new("RGB", (W, H), (0, 0, 0)), min(0.95, self.dim))
        mask = Image.new("L", (W, H), 0)
        md = ImageDraw.Draw(mask)
        md.rectangle((0, 0, W, HEAD_H), fill=165)
        md.rectangle((0, ctrl_y, W, H), fill=165)
        img = Image.composite(Image.new("RGB", (W, H), hex_rgb(self.c["band"])), img, mask)
        self._bg_photo = ImageTk.PhotoImage(img)
        self.canvas.itemconfig("bg", image=self._bg_photo)

    def _add_region(self, name, x0, y0, x1, y1, kind="button", cb=None):
        self.regions.append({"name": name, "x0": x0, "y0": y0, "x1": x1, "y1": y1, "kind": kind, "cb": cb})

    def _region_at(self, x, y):
        for r in reversed(self.regions):
            if r["x0"] <= x <= r["x1"] and r["y0"] <= y <= r["y1"]:
                return r
        return None

    def _icon(self, kind, cx, cy, r, color, tag):
        cv = self.canvas
        tags = ("ui", tag)
        if kind == "play":
            cv.create_polygon(cx - r * 0.6, cy - r, cx - r * 0.6, cy + r, cx + r * 0.95, cy,
                              fill=color, outline="", tags=tags)
        elif kind == "pause":
            cv.create_rectangle(cx - r * 0.7, cy - r, cx - r * 0.2, cy + r, fill=color, outline="", tags=tags)
            cv.create_rectangle(cx + r * 0.2, cy - r, cx + r * 0.7, cy + r, fill=color, outline="", tags=tags)
        elif kind == "prev":
            cv.create_rectangle(cx - r, cy - r, cx - r * 0.65, cy + r, fill=color, outline="", tags=tags)
            cv.create_polygon(cx + r, cy - r, cx + r, cy + r, cx - r * 0.5, cy, fill=color, outline="", tags=tags)
        elif kind == "next":
            cv.create_rectangle(cx + r * 0.65, cy - r, cx + r, cy + r, fill=color, outline="", tags=tags)
            cv.create_polygon(cx - r, cy - r, cx - r, cy + r, cx + r * 0.5, cy, fill=color, outline="", tags=tags)
        elif kind == "stop":
            cv.create_rectangle(cx - r * 0.8, cy - r * 0.8, cx + r * 0.8, cy + r * 0.8,
                                fill=color, outline="", tags=tags)
        elif kind == "min":
            cv.create_line(cx - r * 0.8, cy + r * 0.5, cx + r * 0.8, cy + r * 0.5, fill=color, width=2, tags=tags)
        elif kind == "max":
            if self._maxed:
                cv.create_rectangle(cx - r * 0.8, cy - r * 0.4, cx + r * 0.4, cy + r * 0.8, outline=color, width=2, tags=tags)
                cv.create_line(cx - r * 0.4, cy - r * 0.8, cx + r * 0.8, cy - r * 0.8, cx + r * 0.8, cy + r * 0.4,
                               fill=color, width=2, tags=tags)
            else:
                cv.create_rectangle(cx - r * 0.8, cy - r * 0.8, cx + r * 0.8, cy + r * 0.8, outline=color, width=2, tags=tags)
        elif kind == "close":
            cv.create_line(cx - r * 0.8, cy - r * 0.8, cx + r * 0.8, cy + r * 0.8, fill=color, width=2, tags=tags)
            cv.create_line(cx - r * 0.8, cy + r * 0.8, cx + r * 0.8, cy - r * 0.8, fill=color, width=2, tags=tags)
        elif kind == "pin":
            col = color if self.topmost else self.c["dim"]
            cv.create_polygon(cx - r * 0.7, cy + r * 0.1, cx + r * 0.7, cy + r * 0.1, cx, cy - r * 0.8,
                              fill=col, outline="", tags=tags)
            cv.create_line(cx - r * 0.7, cy + r * 0.7, cx + r * 0.7, cy + r * 0.7, fill=col, width=2, tags=tags)
        elif kind == "list":
            col = color if self.show_playlist else self.c["dim"]
            for k in (-0.6, 0, 0.6):
                cv.create_line(cx - r * 0.8, cy + r * k, cx + r * 0.8, cy + r * k, fill=col, width=2, tags=tags)
        elif kind == "gear":
            cv.create_text(cx, cy, text="⚙", fill=color, font=self.f_sym, tags=tags)

    def _button(self, name, kind, x0, y0, size, cb, filled, hover_fill=None, r=None):
        c = self.c
        cv = self.canvas
        x1, y1 = x0 + size, y0 + size
        normal = c["btn"] if filled else ""
        cv.create_rectangle(x0, y0, x1, y1, fill=normal, outline=c["accent"] if filled else "",
                            tags=("ui", name + "_bg"))
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        rr = r if r is not None else size * 0.28
        self._icon(kind, cx, cy, rr, c["accent"], name + "_ic")
        self.btn_style[name] = (normal, hover_fill or c["btn_hover"])
        self._add_region(name, x0, y0, x1, y1, "button", cb)
        return cx, cy, rr

    def _relayout(self):
        self._layout_job = None
        cv = self.canvas
        W, H = cv.winfo_width(), cv.winfo_height()
        if W < 50 or H < 50:
            return
        c = self.c
        margin = 10
        disc_d = max(64, min(150, int(H * 0.25)))
        ctrl_h = max(disc_d + 22, 96)
        ctrl_y = H - ctrl_h
        pl_vis = self.show_playlist and W >= 500
        pl_w = max(180, min(280, int(W * 0.30))) if pl_vis else 0
        vy = HEAD_H + 8
        vh = max(40, ctrl_y - vy - 8)
        vw = max(60, W - 2 * margin - (pl_w + 8 if pl_vis else 0))
        self.video_frame.place(x=margin, y=vy, width=vw, height=vh)
        if pl_vis:
            self.playlist_view.place(x=W - margin - pl_w, y=vy, width=pl_w, height=vh)
        else:
            self.playlist_view.place_forget()

        self._render_bg(W, H, ctrl_y)
        cv.delete("ui")
        self.regions = []
        self.btn_style = {}
        self._hover = None

        # --- шапка
        bx = W - 12 - 28
        for name, kind, cb in (("close", "close", self.close_app), ("max", "max", self.toggle_maximize),
                               ("min", "min", self.minimize), ("pin", "pin", self.toggle_topmost),
                               ("playlist", "list", self.toggle_playlist), ("settings", "gear", self.open_settings)):
            self._button(name, kind, bx, 3, 28, cb, filled=False,
                         hover_fill="#8b1a1a" if name == "close" else None, r=7)
            bx -= 32
        title_w = bx - 12
        cv.create_text(12, HEAD_H // 2, text=fit_text(self.f_title, "DRAKENIER // VIDEO WIDGET", title_w),
                       anchor="w", fill=c["accent"], font=self.f_title, tags="ui")
        cv.create_line(0, HEAD_H, W, HEAD_H, fill=c["accent"], tags="ui")

        # --- диск
        if disc_d != self.disc_d or self.disc_src is None:
            self.disc_d = disc_d
            self.disc_src = self.disc_base.resize((disc_d, disc_d), RS.LANCZOS)
        dcx, dcy = margin + disc_d / 2 + 4, ctrl_y + ctrl_h / 2
        cv.create_image(dcx, dcy, tags=("ui", "disc"))
        self._render_disc()

        # --- панель управления
        x0 = margin + disc_d + 22
        x1 = W - margin
        block_h = 84
        top = ctrl_y + (ctrl_h - block_h) // 2
        cv.create_line(0, ctrl_y, W, ctrl_y, fill=c["accent"], tags="ui")

        time_w = self.f_small.measure("00:00 / 00:00") + 10
        self._title_maxw = max(40, x1 - x0 - time_w - 8)
        cv.create_text(x0, top + 8, anchor="w", fill=c["accent"], font=self.f_small, tags=("ui", "title_txt"),
                       text=fit_text(self.f_small, self.now_text, self._title_maxw))
        cv.create_text(x1, top + 8, anchor="e", fill=c["accent"], font=self.f_small, tags=("ui", "time_txt"),
                       text=self._time_text())

        sk = self.sl["seek"]
        sk.update(x0=x0, x1=max(x0 + 40, x1), y=top + 34)
        self._draw_slider("seek")
        self._add_region("seek", sk["x0"] - 6, sk["y"] - 10, sk["x1"] + 6, sk["y"] + 10, "slider")

        by = top + 49
        bsz = 30
        bx0 = x0
        for i, (name, kind, cb) in enumerate((("prev", "prev", self.play_prev), ("play", "play", self.toggle_play),
                                              ("next", "next", self.play_next), ("stop", "stop", self.stop_playback))):
            cx, cy, rr = self._button(name, kind if name != "play" else ("pause" if self.is_playing else "play"),
                                      bx0 + i * (bsz + 8), by, bsz, cb, filled=True)
            if name == "play":
                self._play_pos = (cx, cy, rr)
        btn_end = bx0 + 4 * (bsz + 8)
        vol_x1 = x1
        vol_x0 = max(btn_end + 40, vol_x1 - 130)
        vs = self.sl["vol"]
        if vol_x1 - vol_x0 >= 50:
            cv.create_text(vol_x0 - 6, by + bsz / 2, text="VOL", anchor="e", fill=c["accent"],
                           font=self.f_small, tags="ui")
            vs.update(x0=vol_x0, x1=vol_x1, y=by + bsz / 2)
            self._draw_slider("vol")
            self._add_region("vol", vol_x0 - 6, by, vol_x1 + 6, by + bsz, "slider")

        # --- рамка окна
        cv.create_rectangle(1, 1, W - 1, H - 1, outline=c["accent"], width=2, tags="ui")

    def _draw_slider(self, name):
        s = self.sl[name]
        c = self.c
        cv = self.canvas
        tag = "sl_" + name
        cv.delete(tag)
        x0, x1, y, f = s["x0"], s["x1"], s["y"], max(0.0, min(1.0, s["frac"]))
        xf = x0 + (x1 - x0) * f
        cv.create_rectangle(x0, y - 2, x1, y + 2, fill=c["track"], outline="", tags=("ui", tag))
        if xf > x0:
            cv.create_rectangle(x0, y - 2, xf, y + 2, fill=c["accent"], outline="", tags=("ui", tag))
        cv.create_oval(xf - 6, y - 6, xf + 6, y + 6, fill=c["accent"], outline=c["panel"], width=2, tags=("ui", tag))

    def _update_play_icon(self):
        cx, cy, rr = self._play_pos
        self.canvas.delete("play_ic")
        self._icon("pause" if self.is_playing else "play", cx, cy, rr, self.c["accent"], "play_ic")

    def _time_text(self):
        try:
            return "%s / %s" % (fmt_time(self.player.get_time()), fmt_time(self.player.get_length()))
        except Exception:
            return "00:00 / 00:00"

    def _refresh_title(self):
        self.canvas.itemconfig("title_txt", text=fit_text(self.f_small, self.now_text, self._title_maxw))

    # ------------------------------------------------------------ диск (анимация)

    def _render_disc(self):
        if self.disc_src is None:
            return
        frame = self.disc_src.rotate(-self.angle, resample=RS.BICUBIC)
        self._disc_photo = ImageTk.PhotoImage(frame)
        self.canvas.itemconfig("disc", image=self._disc_photo)

    def _anim(self):
        try:
            now = time.time()
            dt = min(0.1, now - self._last_t)
            self._last_t = now
            target = self.disc_speed if self.is_playing else 0.0
            self.vel += (target - self.vel) * min(1.0, dt * 4.0)
            if target == 0.0 and self.vel < 0.5:
                self.vel = 0.0
            else:
                self.angle = (self.angle + self.vel * dt) % 360.0
                self._render_disc()
        except Exception:
            pass
        self.after(33, self._anim)

    # ------------------------------------------------------------ мышь

    def _edge_zone(self, x, y):
        if self._maxed:
            return ""
        W, H = self.canvas.winfo_width(), self.canvas.winfo_height()
        left, right = x < EDGE, x >= W - EDGE
        top, bottom = y < EDGE, y >= H - EDGE
        # углы захватываем пошире
        if x < CORNER or x >= W - CORNER:
            top = top or y < CORNER
            bottom = bottom or y >= H - CORNER
        if y < CORNER or y >= H - CORNER:
            left = left or x < CORNER
            right = right or x >= W - CORNER
        ns = "n" if top else ("s" if bottom else "")
        ew = "w" if left else ("e" if right else "")
        return ns + ew

    def _on_press(self, e):
        i = self._row_at(e.y)
        self.press = (i, e.x, e.y) if i is not None else None
        self.dragging = False

    def _on_motion_drag(self, e):
        if not self.press:
            return
        i, px, py = self.press
        if not self.dragging and (abs(e.y - py) > 5 or abs(e.x - px) > 5):
            self.dragging = True
            self.drag_i = i
            self.cv.configure(cursor="fleur")
            self._autoscroll()
        if self.dragging:
            self.drag_y = e.y
            self.redraw()

    def _autoscroll(self):
        if not self.dragging:
            return
        h = self.cv.winfo_height()
        if self.drag_y < 22:
            self._scroll_by(-10)
        elif self.drag_y > h - 22:
            self._scroll_by(10)
        self.after(40, self._autoscroll)

    def _on_release(self, e):
        if not self.press:
            return
        i = self.press[0]
        was_drag = self.dragging
        slot = self._slot() if was_drag else None
        self.press = None
        self.dragging = False
        self.cv.configure(cursor="")
        if was_drag:
            new = slot if slot <= i else slot - 1
            if new != i:
                self.app.on_reorder(i, new)
            else:
                self.redraw()
        else:
            self.app.play_index(i)

    def _on_hover(self, e):
        h = self._row_at(e.y)
        if h != self.hover:
            self.hover = h
            self.redraw()

    def _on_leave(self, e):
        if self.hover is not None:
            self.hover = None
            self.redraw()

    def _on_wheel(self, e):
        self._scroll_by(-int(e.delta / 120 * self.ROW_H * 0.8) if e.delta else 0)

    def _on_menu(self, e):
        c = self.app.c
        i = self._row_at(e.y)
        m = tk.Menu(self, tearoff=0, bg=c["panel"], fg=c["accent"],
                    activebackground=c["btn_hover"], activeforeground=c["accent"])
        if i is not None:
            name = self.items[i]
            m.add_command(label="Задать обложку…", command=lambda: self.app.choose_cover(name))
            m.add_command(label="Сбросить обложку", command=lambda: self.app.reset_cover(name))
            m.add_separator()
        m.add_command(label="Открыть папку videos", command=self.app.open_videos_folder)
        try:
            m.tk_popup(e.x_root, e.y_root)
        finally:
            m.grab_release()


# ---------------------------------------------------------------------------
# Окно «Оформление»
# ---------------------------------------------------------------------------

class SettingsDialog(tk.Toplevel):
    BG = "#101410"
    FG = "#d8e0d8"

    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.title("Оформление")
        self.configure(bg=self.BG)
        self.resizable(False, False)
        self.attributes("-topmost", True)
        self.geometry("+%d+%d" % (app.winfo_x() + 40, app.winfo_y() + 40))
        self.protocol("WM_DELETE_WINDOW", self.close)
        self._building = False
        self._preview = None
        self.build()

    def close(self):
        self.app._dialog = None
        self.destroy()

    def _button(self, parent, text, cmd):
        a = self.app.accent
        return tk.Button(parent, text=text, command=cmd, bg=shade(a, 0.16), fg=a,
                         activebackground=shade(a, 0.38), activeforeground=a, relief="flat",
                         bd=0, padx=10, pady=4, font=self.app.f_small, cursor="hand2")

    def _label(self, parent, text, head=False):
        return tk.Label(parent, text=text, bg=self.BG, fg=self.app.accent if head else self.FG,
                        font=self.app.f_title if head else self.app.f_small, anchor="w")

    def _scale(self, parent, lo, hi, value, cmd, length=260):
        a = self.app.accent
        sc = tk.Scale(parent, from_=lo, to=hi, orient="horizontal", showvalue=True, length=length,
                      bg=self.BG, fg=self.FG, troughcolor=shade(a, 0.22), highlightthickness=0, bd=0,
                      activebackground=a, font=self.app.f_small,
                      command=lambda v: None if self._building else cmd(float(v)))
        sc.set(value)
        return sc

    def build(self):
        self._building = True
        for w in self.winfo_children():
            w.destroy()
        app, a = self.app, self.app.accent
        pad = {"padx": 14}

        self._label(self, "ОБОИ", head=True).pack(fill="x", pady=(12, 4), **pad)
        row = tk.Frame(self, bg=self.BG)
        row.pack(fill="x", **pad)
        for i, (key, label) in enumerate(PRESET_WALLPAPERS):
            self._button(row, label, lambda k=key: app.set_wallpaper("preset", k)).grid(
                row=i // 3, column=i % 3, padx=3, pady=3, sticky="ew")
        self._button(row, "Свой файл…", self.pick_wallpaper).grid(row=1, column=2, padx=3, pady=3, sticky="ew")
        self._label(self, "Затемнение обоев, %").pack(fill="x", pady=(8, 0), **pad)
        self._scale(self, 0, 90, int(app.dim * 100), lambda v: app.set_dim(v / 100.0)).pack(**pad)

        self._label(self, "ЦВЕТ ОФОРМЛЕНИЯ", head=True).pack(fill="x", pady=(12, 4), **pad)
        sw = tk.Frame(self, bg=self.BG)
        sw.pack(fill="x", **pad)
        for col in ACCENT_CHOICES:
            b = tk.Frame(sw, bg=col, width=28, height=28, cursor="hand2",
                         highlightthickness=2, highlightbackground=("#ffffff" if col.lower() == a.lower() else self.BG))
            b.pack(side="left", padx=3)
            b.bind("<Button-1>", lambda e, c=col: self.pick_color(c))
        self._button(sw, "Свой…", lambda: self.pick_color(None)).pack(side="left", padx=8)

        self._label(self, "ДИСК", head=True).pack(fill="x", pady=(12, 4), **pad)
        drow = tk.Frame(self, bg=self.BG)
        drow.pack(fill="x", **pad)
        pv = tk.Canvas(drow, width=96, height=96, bg=self.BG, highlightthickness=0)
        pv.pack(side="left")
        try:
            self._preview = ImageTk.PhotoImage(app.disc_base.resize((90, 90), RS.LANCZOS))
            pv.create_image(48, 48, image=self._preview)
        except Exception:
            pass
        col = tk.Frame(drow, bg=self.BG)
        col.pack(side="left", padx=12)
        self._button(col, "Выбрать картинку…", self.pick_disc).pack(fill="x", pady=2)
        self._button(col, "Вернуть стандартный", self.reset_disc).pack(fill="x", pady=2)
        self._label(self, "Скорость вращения").pack(fill="x", pady=(8, 0), **pad)
        self._scale(self, 30, 360, int(app.disc_speed), lambda v: app.set_speed(v)).pack(**pad)

        self._button(self, "Готово", self.close).pack(pady=14)
        self._building = False

    def pick_wallpaper(self):
        path = filedialog.askopenfilename(
            parent=self, title="Выберите картинку для обоев",
            filetypes=[("Изображения", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("Все файлы", "*.*")])
        if path:
            self.app.set_wallpaper("file", path)

    def pick_color(self, col):
        if col is None:
            res = colorchooser.askcolor(color=self.app.accent, parent=self, title="Цвет оформления")
            col = res[1] if res else None
        if col:
            self.app.set_accent(col)
            self.build()

    def pick_disc(self):
        path = filedialog.askopenfilename(
            parent=self, title="Выберите картинку для диска",
            filetypes=[("Изображения", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("Все файлы", "*.*")])
        if path and self.app.set_disc_file(path):
            self.build()

    def reset_disc(self):
        self.app.reset_disc()
        self.build()


# ---------------------------------------------------------------------------
# Главное окно
# ---------------------------------------------------------------------------

class VideoWidget(tk.Tk):
    def __init__(self):
        super().__init__()
        self.settings = Settings(SETTINGS_PATH)
        s = self.settings
        self.accent = s.get("accent") or DEFAULT_ACCENT
        self.c = make_colors(self.accent)
        self.dim = float(s.get("dim") or 0)
        self.disc_speed = float(s.get("disc_speed") or 120)
        self.topmost = bool(s.get("topmost"))
        self.show_playlist = bool(s.get("show_playlist"))

        self.title("drakeNier widget")
        self.configure(bg="#000000")
        self._set_icon()

        self.f_title = tkfont.Font(family=FONT_NAME, size=11, weight="bold")
        self.f_small = tkfont.Font(family=FONT_NAME, size=9)
        self.f_tiny = tkfont.Font(family=FONT_NAME, size=8)
        self.f_sym = tkfont.Font(family=("Segoe UI Symbol" if IS_WIN else "DejaVu Sans"), size=13)

        self._init_geometry()

        # состояние
        self.playlist = []
        self.current_index = None
        self.is_playing = False
        self.now_text = "— нет видео —"
        self.regions = []
        self.btn_style = {}
        self.sl = {"seek": {"x0": 0, "x1": 1, "y": 0, "frac": 0.0},
                   "vol": {"x0": 0, "x1": 1, "y": 0, "frac": max(0, min(100, int(s.get("volume") or 80))) / 100.0}}
        self._hover = None
        self._cursor = ""
        self._mode = None
        self._active = None
        self._rs = None
        self._drag_x = self._drag_y = 0
        self._seeking = False
        self._ended = False
        self._maxed = False
        self._minimized = False
        self._normal_rect = None
        self._saved_geo = None
        self._layout_job = None
        self._probe_token = 0
        self._vol_applied = False
        self._dialog = None
        self._play_pos = (0, 0, 8)
        self._title_maxw = 100
        self._bg_photo = None
        self._disc_photo = None
        self.angle = 0.0
        self.vel = 0.0
        self._last_t = time.time()
        self.disc_d = 0
        self.disc_src = None
        self.disc_base = None
        self.wp_src = None

        # холст на всё окно: обои + рисованные элементы
        self.canvas = tk.Canvas(self, bg=self.c["bg"], highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_image(0, 0, anchor="nw", tags="bg")

        self.video_frame = tk.Frame(self, bg="black", highlightthickness=1,
                                    highlightbackground=self.accent, highlightcolor=self.accent)
        self.playlist_view = PlaylistView(self, self)
        self.covers = CoverManager(self.settings)

        self._load_disc()
        self._load_wallpaper()

        # VLC
        self.vlc_instance = vlc.Instance("--quiet")
        self.player = self.vlc_instance.media_player_new()
        try:
            self.player.video_set_mouse_input(False)
            self.player.video_set_key_input(False)
        except Exception:
            pass
        events = self.player.event_manager()
        events.event_attach(vlc.EventType.MediaPlayerEndReached, self._on_video_end)

        # события мыши и клавиатуры
        cv = self.canvas
        cv.bind("<ButtonPress-1>", self._on_press)
        cv.bind("<B1-Motion>", self._on_drag)
        cv.bind("<ButtonRelease-1>", self._on_release)
        cv.bind("<Motion>", self._on_motion)
        cv.bind("<Leave>", lambda e: self._set_hover(None))
        cv.bind("<Double-Button-1>", self._on_double)
        cv.bind("<Configure>", lambda e: self._schedule_layout())
        self.bind("<space>", lambda e: self.toggle_play())
        self.bind("<Left>", lambda e: self.seek_relative(-10000))
        self.bind("<Right>", lambda e: self.seek_relative(10000))
        self.protocol("WM_DELETE_WINDOW", self.close_app)

        # окно без системной рамки, но с кнопкой на панели задач
        self.overrideredirect(True)
        self.attributes("-topmost", self.topmost)

        self.update_idletasks()
        self._relayout()
        self._embed_player()
        self.after(150, self._apply_appwindow)

        self.playlist = self._merge_order(scan_videos())
        self.settings.set("order", list(self.playlist))
        self.playlist_view.set_items(self.playlist)
        if self.playlist:
            self.play_index(0)
        self._apply_volume()

        self.after(POLL_INTERVAL_MS, self._poll_folder)
        self.after(300, self._tick)
        self.after(500, self._poll_covers)
        self.after(33, self._anim)

    # ------------------------------------------------------------ старт

    def _set_icon(self):
        ico = os.path.join(ASSETS_DIR, "icon.ico")
        png = os.path.join(ASSETS_DIR, "icon.png")
        try:
            if IS_WIN and os.path.exists(ico):
                self.iconbitmap(default=ico)
            elif os.path.exists(png):
                self._icon_img = ImageTk.PhotoImage(Image.open(png))
                self.iconphoto(True, self._icon_img)
        except Exception:
            pass

    def _init_geometry(self):
        g = self.settings.get("geometry") or {}
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        try:
            w = max(MIN_W, min(sw, int(g.get("w", 720))))
            h = max(MIN_H, min(sh, int(g.get("h", 460))))
            x = int(g.get("x", 80))
            y = int(g.get("y", 80))
        except Exception:
            w, h, x, y = 720, 460, 80, 80
        x = max(-w + 120, min(sw - 120, x))
        y = max(0, min(sh - 60, y))
        self.geometry("%dx%d+%d+%d" % (w, h, x, y))

    def _load_disc(self):
        path = None
        if self.settings.get("disc") == "custom":
            p = os.path.join(DATA_DIR, "disc_custom.png")
            if os.path.exists(p):
                path = p
        if not path:
            path = os.path.join(ASSETS_DIR, "disc_default.png")
        try:
            self.disc_base = process_disc_image(Image.open(path))
        except Exception:
            self.disc_base = fallback_disc(self.accent)

    def _load_wallpaper(self):
        wp = self.settings.get("wallpaper") or {}
        img = None
        try:
            if wp.get("kind") == "file" and wp.get("value") and os.path.exists(wp["value"]):
                img = Image.open(wp["value"]).convert("RGB")
                img.thumbnail((1920, 1920), RS.LANCZOS)
            else:
                img = make_preset(wp.get("value") or "grid", self.accent)
        except Exception:
            img = None
        if img is None:
            try:
                img = make_preset("grid", self.accent)
            except Exception:
                img = Image.new("RGB", (64, 64), hex_rgb(self.c["bg"]))
        self.wp_src = img

    def _embed_player(self):
        self.update_idletasks()
        handle = self.video_frame.winfo_id()
        if IS_WIN:
            self.player.set_hwnd(handle)
        elif sys.platform.startswith("linux"):
            self.player.set_xwindow(handle)
        elif sys.platform == "darwin":
            self.player.set_nsobject(handle)

    def _apply_appwindow(self):
        """Окно без рамки получает кнопку на панели задач, как обычное приложение."""
        if not IS_WIN:
            return
        try:
            import ctypes
            GWL_EXSTYLE, WS_EX_APPWINDOW, WS_EX_TOOLWINDOW = -20, 0x00040000, 0x00000080
            user32 = ctypes.windll.user32
            hwnd = user32.GetParent(self.winfo_id())
            style = user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            user32.SetWindowLongW(hwnd, GWL_EXSTYLE, (style & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW)
            self.withdraw()
            self.after(40, self._after_appwindow)
        except Exception:
            pass

    def _after_appwindow(self):
        self.deiconify()
        self.attributes("-topmost", self.topmost)
        self.after(60, self._embed_player)

    # ------------------------------------------------------------ раскладка

    def _schedule_layout(self):
        if self._layout_job is None:
            self._layout_job = self.after_idle(self._relayout)

    def _render_bg(self, W, H, ctrl_y):
        src = self.wp_src
        sw, sh = src.size
        sc = max(W / sw, H / sh)
        nw, nh = max(W, int(sw * sc + 0.5)), max(H, int(sh * sc + 0.5))
        l, t = (nw - W) // 2, (nh - H) // 2
        img = src.resize((nw, nh), RS.BILINEAR).crop((l, t, l + W, t + H))
        if self.dim > 0:
            img = Image.blend(img, Image.new("RGB", (W, H), (0, 0, 0)), min(0.95, self.dim))
        mask = Image.new("L", (W, H), 0)
        md = ImageDraw.Draw(mask)
        md.rectangle((0, 0, W, HEAD_H), fill=165)
        md.rectangle((0, ctrl_y, W, H), fill=165)
        img = Image.composite(Image.new("RGB", (W, H), hex_rgb(self.c["band"])), img, mask)
        self._bg_photo = ImageTk.PhotoImage(img)
        self.canvas.itemconfig("bg", image=self._bg_photo)

    def _add_region(self, name, x0, y0, x1, y1, kind="button", cb=None):
        self.regions.append({"name": name, "x0": x0, "y0": y0, "x1": x1, "y1": y1, "kind": kind, "cb": cb})

    def _region_at(self, x, y):
        for r in reversed(self.regions):
            if r["x0"] <= x <= r["x1"] and r["y0"] <= y <= r["y1"]:
                return r
        return None

    def _icon(self, kind, cx, cy, r, color, tag):
        cv = self.canvas
        tags = ("ui", tag)
        if kind == "play":
            cv.create_polygon(cx - r * 0.6, cy - r, cx - r * 0.6, cy + r, cx + r * 0.95, cy,
                              fill=color, outline="", tags=tags)
        elif kind == "pause":
            cv.create_rectangle(cx - r * 0.7, cy - r, cx - r * 0.2, cy + r, fill=color, outline="", tags=tags)
            cv.create_rectangle(cx + r * 0.2, cy - r, cx + r * 0.7, cy + r, fill=color, outline="", tags=tags)
        elif kind == "prev":
            cv.create_rectangle(cx - r, cy - r, cx - r * 0.65, cy + r, fill=color, outline="", tags=tags)
            cv.create_polygon(cx + r, cy - r, cx + r, cy + r, cx - r * 0.5, cy, fill=color, outline="", tags=tags)
        elif kind == "next":
            cv.create_rectangle(cx + r * 0.65, cy - r, cx + r, cy + r, fill=color, outline="", tags=tags)
            cv.create_polygon(cx - r, cy - r, cx - r, cy + r, cx + r * 0.5, cy, fill=color, outline="", tags=tags)
        elif kind == "stop":
            cv.create_rectangle(cx - r * 0.8, cy - r * 0.8, cx + r * 0.8, cy + r * 0.8,
                                fill=color, outline="", tags=tags)
        elif kind == "min":
            cv.create_line(cx - r * 0.8, cy + r * 0.5, cx + r * 0.8, cy + r * 0.5, fill=color, width=2, tags=tags)
        elif kind == "max":
            if self._maxed:
                cv.create_rectangle(cx - r * 0.8, cy - r * 0.4, cx + r * 0.4, cy + r * 0.8, outline=color, width=2, tags=tags)
                cv.create_line(cx - r * 0.4, cy - r * 0.8, cx + r * 0.8, cy - r * 0.8, cx + r * 0.8, cy + r * 0.4,
                               fill=color, width=2, tags=tags)
            else:
                cv.create_rectangle(cx - r * 0.8, cy - r * 0.8, cx + r * 0.8, cy + r * 0.8, outline=color, width=2, tags=tags)
        elif kind == "close":
            cv.create_line(cx - r * 0.8, cy - r * 0.8, cx + r * 0.8, cy + r * 0.8, fill=color, width=2, tags=tags)
            cv.create_line(cx - r * 0.8, cy + r * 0.8, cx + r * 0.8, cy - r * 0.8, fill=color, width=2, tags=tags)
        elif kind == "pin":
            col = color if self.topmost else self.c["dim"]
            cv.create_polygon(cx - r * 0.7, cy + r * 0.1, cx + r * 0.7, cy + r * 0.1, cx, cy - r * 0.8,
                              fill=col, outline="", tags=tags)
            cv.create_line(cx - r * 0.7, cy + r * 0.7, cx + r * 0.7, cy + r * 0.7, fill=col, width=2, tags=tags)
        elif kind == "list":
            col = color if self.show_playlist else self.c["dim"]
            for k in (-0.6, 0, 0.6):
                cv.create_line(cx - r * 0.8, cy + r * k, cx + r * 0.8, cy + r * k, fill=col, width=2, tags=tags)
        elif kind == "gear":
            cv.create_text(cx, cy, text="⚙", fill=color, font=self.f_sym, tags=tags)

    def _button(self, name, kind, x0, y0, size, cb, filled, hover_fill=None, r=None):
        c = self.c
        cv = self.canvas
        x1, y1 = x0 + size, y0 + size
        normal = c["btn"] if filled else ""
        cv.create_rectangle(x0, y0, x1, y1, fill=normal, outline=c["accent"] if filled else "",
                            tags=("ui", name + "_bg"))
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        rr = r if r is not None else size * 0.28
        self._icon(kind, cx, cy, rr, c["accent"], name + "_ic")
        self.btn_style[name] = (normal, hover_fill or c["btn_hover"])
        self._add_region(name, x0, y0, x1, y1, "button", cb)
        return cx, cy, rr

    def _relayout(self):
        self._layout_job = None
        cv = self.canvas
        W, H = cv.winfo_width(), cv.winfo_height()
        if W < 50 or H < 50:
            return
        c = self.c
        margin = 10
        disc_d = max(64, min(150, int(H * 0.25)))
        ctrl_h = max(disc_d + 22, 96)
        ctrl_y = H - ctrl_h
        pl_vis = self.show_playlist and W >= 500
        pl_w = max(180, min(280, int(W * 0.30))) if pl_vis else 0
        vy = HEAD_H + 8
        vh = max(40, ctrl_y - vy - 8)
        vw = max(60, W - 2 * margin - (pl_w + 8 if pl_vis else 0))
        self.video_frame.place(x=margin, y=vy, width=vw, height=vh)
        if pl_vis:
            self.playlist_view.place(x=W - margin - pl_w, y=vy, width=pl_w, height=vh)
        else:
            self.playlist_view.place_forget()

        self._render_bg(W, H, ctrl_y)
        cv.delete("ui")
        self.regions = []
        self.btn_style = {}
        self._hover = None

        # --- шапка
        bx = W - 12 - 28
        for name, kind, cb in (("close", "close", self.close_app), ("max", "max", self.toggle_maximize),
                               ("min", "min", self.minimize), ("pin", "pin", self.toggle_topmost),
                               ("playlist", "list", self.toggle_playlist), ("settings", "gear", self.open_settings)):
            self._button(name, kind, bx, 3, 28, cb, filled=False,
                         hover_fill="#8b1a1a" if name == "close" else None, r=7)
            bx -= 32
        title_w = bx - 12
        cv.create_text(12, HEAD_H // 2, text=fit_text(self.f_title, "DRAKENIER // VIDEO WIDGET", title_w),
                       anchor="w", fill=c["accent"], font=self.f_title, tags="ui")
        cv.create_line(0, HEAD_H, W, HEAD_H, fill=c["accent"], tags="ui")

        # --- диск
        if disc_d != self.disc_d or self.disc_src is None:
            self.disc_d = disc_d
            self.disc_src = self.disc_base.resize((disc_d, disc_d), RS.LANCZOS)
        dcx, dcy = margin + disc_d / 2 + 4, ctrl_y + ctrl_h / 2
        cv.create_image(dcx, dcy, tags=("ui", "disc"))
        self._render_disc()

        # --- панель управления
        x0 = margin + disc_d + 22
        x1 = W - margin
        block_h = 84
        top = ctrl_y + (ctrl_h - block_h) // 2
        cv.create_line(0, ctrl_y, W, ctrl_y, fill=c["accent"], tags="ui")

        time_w = self.f_small.measure("00:00 / 00:00") + 10
        self._title_maxw = max(40, x1 - x0 - time_w - 8)
        cv.create_text(x0, top + 8, anchor="w", fill=c["accent"], font=self.f_small, tags=("ui", "title_txt"),
                       text=fit_text(self.f_small, self.now_text, self._title_maxw))
        cv.create_text(x1, top + 8, anchor="e", fill=c["accent"], font=self.f_small, tags=("ui", "time_txt"),
                       text=self._time_text())

        sk = self.sl["seek"]
        sk.update(x0=x0, x1=max(x0 + 40, x1), y=top + 34)
        self._draw_slider("seek")
        self._add_region("seek", sk["x0"] - 6, sk["y"] - 10, sk["x1"] + 6, sk["y"] + 10, "slider")

        by = top + 49
        bsz = 30
        bx0 = x0
        for i, (name, kind, cb) in enumerate((("prev", "prev", self.play_prev), ("play", "play", self.toggle_play),
                                              ("next", "next", self.play_next), ("stop", "stop", self.stop_playback))):
            cx, cy, rr = self._button(name, kind if name != "play" else ("pause" if self.is_playing else "play"),
                                      bx0 + i * (bsz + 8), by, bsz, cb, filled=True)
            if name == "play":
                self._play_pos = (cx, cy, rr)
        btn_end = bx0 + 4 * (bsz + 8)
        vol_x1 = x1
        vol_x0 = max(btn_end + 40, vol_x1 - 130)
        vs = self.sl["vol"]
        if vol_x1 - vol_x0 >= 50:
            cv.create_text(vol_x0 - 6, by + bsz / 2, text="VOL", anchor="e", fill=c["accent"],
                           font=self.f_small, tags="ui")
            vs.update(x0=vol_x0, x1=vol_x1, y=by + bsz / 2)
            self._draw_slider("vol")
            self._add_region("vol", vol_x0 - 6, by, vol_x1 + 6, by + bsz, "slider")

        # --- рамка окна
        cv.create_rectangle(1, 1, W - 1, H - 1, outline=c["accent"], width=2, tags="ui")

    def _draw_slider(self, name):
        s = self.sl[name]
        c = self.c
        cv = self.canvas
        tag = "sl_" + name
        cv.delete(tag)
        x0, x1, y, f = s["x0"], s["x1"], s["y"], max(0.0, min(1.0, s["frac"]))
        xf = x0 + (x1 - x0) * f
        cv.create_rectangle(x0, y - 2, x1, y + 2, fill=c["track"], outline="", tags=("ui", tag))
        if xf > x0:
            cv.create_rectangle(x0, y - 2, xf, y + 2, fill=c["accent"], outline="", tags=("ui", tag))
        cv.create_oval(xf - 6, y - 6, xf + 6, y + 6, fill=c["accent"], outline=c["panel"], width=2, tags=("ui", tag))

    def _update_play_icon(self):
        cx, cy, rr = self._play_pos
        self.canvas.delete("play_ic")
        self._icon("pause" if self.is_playing else "play", cx, cy, rr, self.c["accent"], "play_ic")

    def _time_text(self):
        try:
            return "%s / %s" % (fmt_time(self.player.get_time()), fmt_time(self.player.get_length()))
        except Exception:
            return "00:00 / 00:00"

    def _refresh_title(self):
        self.canvas.itemconfig("title_txt", text=fit_text(self.f_small, self.now_text, self._title_maxw))

    # ------------------------------------------------------------ диск (анимация)

    def _render_disc(self):
        if self.disc_src is None:
            return
        frame = self.disc_src.rotate(-self.angle, resample=RS.BICUBIC)
        self._disc_photo = ImageTk.PhotoImage(frame)
        self.canvas.itemconfig("disc", image=self._disc_photo)

    def _anim(self):
        try:
            now = time.time()
            dt = min(0.1, now - self._last_t)
            self._last_t = now
            target = self.disc_speed if self.is_playing else 0.0
            self.vel += (target - self.vel) * min(1.0, dt * 4.0)
            if target == 0.0 and self.vel < 0.5:
                self.vel = 0.0
            else:
                self.angle = (self.angle + self.vel * dt) % 360.0
                self._render_disc()
        except Exception:
            pass
        self.after(33, self._anim)

    # ------------------------------------------------------------ мышь

    def _edge_zone(self, x, y):
        if self._maxed:
            return ""
        W, H = self.canvas.winfo_width(), self.canvas.winfo_height()
        ns = "n" if y < CORNER and (x < CORNER or x >= W - CORNER) else ""
        if y < EDGE:
            ns = "n"
        elif y >= H - EDGE:
            ns = "s"
        elif y >= H - CORNER and (x < CORNER or x >= W - CORNER):
            ns = "s"
        ew = ""
        if x < EDGE:
            ew = "w"
        elif x >= W - EDGE:
            ew = "e"
        elif x < CORNER and (y < CORNER or y >= H - CORNER):
            ew = "w"
        elif x >= W - CORNER and (y < CORNER or y >= H - CORNER):
            ew = "e"
        return ns + ew

    def _on_press(self, e):
        self.canvas.focus_set()
        z = self._edge_zone(e.x, e.y)
        if z:
            self._mode = "resize"
            self._rs = (z, e.x_root, e.y_root, self.winfo_x(), self.winfo_y(),
                        self.winfo_width(), self.winfo_height())
            return
        r = self._region_at(e.x, e.y)
        if r:
            if r["kind"] == "button":
                self._mode = None
                r["cb"]()
            else:
                self._mode = "slider"
                self._active = r["name"]
                if r["name"] == "seek":
                    self._seeking = True
                self._slider_move(e.x)
            return
        if e.y < HEAD_H and not self._maxed:
            self._mode = "move"
            self._drag_x, self._drag_y = e.x, e.y
            return
        self._mode = None

    def _on_drag(self, e):
        if self._mode == "move":
            x = self.winfo_pointerx() - self._drag_x
            y = self.winfo_pointery() - self._drag_y
            self.geometry("+%d+%d" % (x, y))
        elif self._mode == "resize" and self._rs:
            z, sx, sy, x0, y0, w0, h0 = self._rs
            dx, dy = e.x_root - sx, e.y_root - sy
            x, y, w, h = x0, y0, w0, h0
            if "e" in z:
                w = max(MIN_W, w0 + dx)
            if "s" in z:
                h = max(MIN_H, h0 + dy)
            if "w" in z:
                w = max(MIN_W, w0 - dx)
                x = x0 + (w0 - w)
            if "n" in z:
                h = max(MIN_H, h0 - dy)
                y = y0 + (h0 - h)
            self.geometry("%dx%d+%d+%d" % (w, h, x, y))
        elif self._mode == "slider":
            self._slider_move(e.x)

    def _on_release(self, e):
        if self._mode == "slider" and self._active == "seek":
            self._apply_seek()
            self._seeking = False
        elif self._mode == "slider" and self._active == "vol":
            self.settings.set("volume", int(self.sl["vol"]["frac"] * 100))
            self.settings.save()
        elif self._mode in ("move", "resize"):
            self.settings.set("geometry", self._rect_dict())
            self.settings.save()
        self._mode = None
        self._active = None

    def _on_motion(self, e):
        z = self._edge_zone(e.x, e.y)
        cur = ""
        r = None
        if z:
            cur = CURSORS.get(z, "")
        else:
            r = self._region_at(e.x, e.y)
            if r:
                cur = "hand2"
        if cur != self._cursor:
            self.canvas.configure(cursor=cur)
            self._cursor = cur
        self._set_hover(r["name"] if (r and r["kind"] == "button") else None)

    def _on_double(self, e):
        if e.y < HEAD_H and not self._edge_zone(e.x, e.y) and not self._region_at(e.x, e.y):
            self.toggle_maximize()

    def _set_hover(self, name):
        if name == self._hover:
            return
        for nm, state in ((self._hover, False), (name, True)):
            if nm and nm in self.btn_style:
                normal, hov = self.btn_style[nm]
                self.canvas.itemconfig(nm + "_bg", fill=hov if state else normal)
        self._hover = name

    def _slider_move(self, x):
        s = self.sl[self._active]
        f = (x - s["x0"]) / max(1, s["x1"] - s["x0"])
        s["frac"] = max(0.0, min(1.0, f))
        self._draw_slider(self._active)
        if self._active == "vol":
            self._apply_volume()
        elif self._active == "seek":
            try:
                length = self.player.get_length()
                if length and length > 0:
                    self.canvas.itemconfig("time_txt", text="%s / %s" % (fmt_time(s["frac"] * length), fmt_time(length)))
            except Exception:
                pass

    # ------------------------------------------------------------ окно

    def _rect_dict(self):
        if self._maxed and self._normal_rect:
            w, h, x, y = self._normal_rect
        else:
            w, h, x, y = self.winfo_width(), self.winfo_height(), self.winfo_x(), self.winfo_y()
        return {"w": w, "h": h, "x": x, "y": y}

    def toggle_maximize(self):
        if self._maxed:
            w, h, x, y = self._normal_rect
            self._maxed = False
            self.geometry("%dx%d+%d+%d" % (w, h, x, y))
        else:
            self._normal_rect = (self.winfo_width(), self.winfo_height(), self.winfo_x(), self.winfo_y())
            ax, ay, aw, ah = work_area(self)
            self._maxed = True
            self.geometry("%dx%d+%d+%d" % (aw, ah, ax, ay))
        self._relayout()

    def minimize(self):
        self._minimized = True
        self._saved_geo = "%dx%d+%d+%d" % (self.winfo_width(), self.winfo_height(), self.winfo_x(), self.winfo_y())
        self.overrideredirect(False)
        self.update_idletasks()
        self.iconify()
        self.bind("<Map>", self._on_restore)

    def _on_restore(self, e):
        if e.widget is not self or not self._minimized:
            return
        self._minimized = False
        self.unbind("<Map>")
        self.after(60, self._finish_restore)

    def _finish_restore(self):
        self.overrideredirect(True)
        if self._saved_geo:
            self.geometry(self._saved_geo)
        self.attributes("-topmost", self.topmost)
        self._apply_appwindow()

    def toggle_topmost(self):
        self.topmost = not self.topmost
        self.attributes("-topmost", self.topmost)
        self.settings.set("topmost", self.topmost)
        self.settings.save()
        self._relayout()

    def toggle_playlist(self):
        self.show_playlist = not self.show_playlist
        self.settings.set("show_playlist", self.show_playlist)
        self.settings.save()
        self._relayout()

    def open_settings(self):
        if self._dialog is not None:
            try:
                self._dialog.lift()
                return
            except Exception:
                self._dialog = None
        self._dialog = SettingsDialog(self)

    def close_app(self):
        try:
            self.settings.set("geometry", self._rect_dict())
            self.settings.set("order", list(self.playlist))
            self.settings.save()
        except Exception:
            pass
        try:
            self.player.stop()
            self.player.release()
        except Exception:
            pass
        self.destroy()

    # ------------------------------------------------------------ оформление

    def set_wallpaper(self, kind, value):
        try:
            if kind == "file":
                img = Image.open(value).convert("RGB")
                img.thumbnail((1920, 1920), RS.LANCZOS)
                dst = os.path.join(DATA_DIR, "wallpaper_custom.jpg")
                img.save(dst, "JPEG", quality=90)
                self.wp_src = img
                self.settings.set("wallpaper", {"kind": "file", "value": dst})
            else:
                self.wp_src = make_preset(value, self.accent)
                self.settings.set("wallpaper", {"kind": "preset", "value": value})
        except Exception as exc:
            messagebox.showerror("Обои", "Не удалось установить обои:\n%s" % exc)
            return
        self.settings.save()
        self._relayout()

    def set_dim(self, value):
        self.dim = max(0.0, min(0.9, value))
        self.settings.set("dim", self.dim)
        self.settings.save()
        self._relayout()

    def set_accent(self, color):
        try:
            hex_rgb(color)
        except Exception:
            return
        self.accent = color
        self.c = make_colors(color)
        self.settings.set("accent", color)
        wp = self.settings.get("wallpaper") or {}
        if wp.get("kind") == "preset":
            self.wp_src = make_preset(wp.get("value") or "grid", color)
        self.canvas.configure(bg=self.c["bg"])
        self.video_frame.configure(highlightbackground=color, highlightcolor=color)
        self.playlist_view.recolor()
        self.settings.save()
        self._relayout()

    def set_speed(self, value):
        self.disc_speed = max(10.0, float(value))
        self.settings.set("disc_speed", self.disc_speed)
        self.settings.save()

    def set_disc_file(self, path):
        try:
            proc = process_disc_image(Image.open(path))
            proc.save(os.path.join(DATA_DIR, "disc_custom.png"))
        except Exception as exc:
            messagebox.showerror("Диск", "Не удалось загрузить картинку:\n%s" % exc)
            return False
        self.disc_base = proc
        self.settings.set("disc", "custom")
        self.settings.save()
        self.disc_src = None
        self._relayout()
        return True

    def reset_disc(self):
        self.settings.set("disc", "default")
        self.settings.save()
        self._load_disc()
        self.disc_src = None
        self._relayout()

    # ------------------------------------------------------------ обложки

    def choose_cover(self, name):
        path = filedialog.askopenfilename(
            parent=self, title="Выберите картинку-обложку",
            filetypes=[("Изображения", "*.png *.jpg *.jpeg *.webp *.bmp"), ("Все файлы", "*.*")])
        if not path:
            return
        try:
            self.covers.set_custom(name, path)
        except Exception as exc:
            messagebox.showerror("Обложка", "Не удалось поставить обложку:\n%s" % exc)
            return
        self.playlist_view.clear_cache()

    def reset_cover(self, name):
        self.covers.clear_custom(name)
        self.playlist_view.clear_cache()

    def open_videos_folder(self):
        try:
            if IS_WIN:
                os.startfile(VIDEOS_DIR)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", VIDEOS_DIR])
            else:
                subprocess.Popen(["xdg-open", VIDEOS_DIR])
        except Exception:
            pass

    def _poll_covers(self):
        try:
            if self.covers.drain():
                self.playlist_view.clear_cache()
        except Exception:
            pass
        self.after(500, self._poll_covers)

    def _probe_cover(self, token, attempt):
        """Запасной способ: снимок кадра средствами VLC, пока видео играет."""
        if token != self._probe_token or self.current_index is None or self.current_index >= len(self.playlist):
            return
        name = self.playlist[self.current_index]
        if self.covers.cover_for(name, request=False):
            return
        if not self.player.is_playing():
            if attempt < 4:
                self.after(1500, lambda: self._probe_cover(token, attempt + 1))
            return
        tmp = os.path.join(COVERS_DIR, "_snap.png")
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
            if self.player.video_take_snapshot(0, tmp, 320, 0) == 0:
                self.after(900, lambda: self._finish_probe(name, tmp, token, attempt))
        except Exception:
            pass

    def _finish_probe(self, name, tmp, token, attempt):
        try:
            if os.path.exists(tmp):
                img = Image.open(tmp).convert("L")
                dark = ImageStat.Stat(img).mean[0] < 10
                if dark and attempt < 3 and token == self._probe_token:
                    self.after(3000, lambda: self._probe_cover(token, attempt + 1))
                else:
                    self.covers.adopt(name, tmp)
                    self.playlist_view.clear_cache()
                try:
                    os.remove(tmp)
                except OSError:
                    pass
        except Exception:
            pass

    # ------------------------------------------------------------ плейлист

    def _merge_order(self, files):
        saved = self.settings.get("order") or []
        ordered = [n for n in saved if n in files]
        rest = sorted([n for n in files if n not in ordered], key=str.lower)
        return ordered + rest

    def _poll_folder(self):
        try:
            files = scan_videos()
            if set(files) != set(self.playlist):
                current_name = None
                if self.current_index is not None and self.current_index < len(self.playlist):
                    current_name = self.playlist[self.current_index]
                self.playlist = self._merge_order(files)
                self.settings.set("order", list(self.playlist))
                self.settings.save()
                self.playlist_view.set_items(self.playlist)
                if current_name in self.playlist:
                    self.current_index = self.playlist.index(current_name)
                    self.playlist_view.set_current(self.current_index)
                elif self.playlist:
                    self.current_index = None
                    if not self.is_playing:
                        self.play_index(0)
                else:
                    self.current_index = None
        except Exception:
            pass
        self.after(POLL_INTERVAL_MS, self._poll_folder)

    def on_reorder(self, old, new):
        current_name = None
        if self.current_index is not None and self.current_index < len(self.playlist):
            current_name = self.playlist[self.current_index]
        name = self.playlist.pop(old)
        self.playlist.insert(new, name)
        self.current_index = self.playlist.index(current_name) if current_name in self.playlist else None
        self.settings.set("order", list(self.playlist))
        self.settings.save()
        self.playlist_view.set_items(self.playlist)
        self.playlist_view.set_current(self.current_index)

    # ------------------------------------------------------------ воспроизведение

    def play_index(self, index):
        if not self.playlist:
            return
        index %= len(self.playlist)
        self.current_index = index
        name = self.playlist[index]
        media = self.vlc_instance.media_new(os.path.join(VIDEOS_DIR, name))
        self.player.set_media(media)
        self.player.play()
        self.is_playing = True
        self._vol_applied = False
        self.now_text = "► " + name
        self.sl["seek"]["frac"] = 0.0
        self._draw_slider("seek")
        self._update_play_icon()
        self._refresh_title()
        self.playlist_view.set_current(index)
        self._probe_token += 1
        token = self._probe_token
        self.after(2500, lambda: self._probe_cover(token, 0))

    def toggle_play(self):
        if self.current_index is None:
            if self.playlist:
                self.play_index(0)
            return
        if self.is_playing:
            self.player.pause()
            self.is_playing = False
        else:
            self.player.play()
            self.is_playing = True
        self._update_play_icon()

    def stop_playback(self):
        self.player.stop()
        self.is_playing = False
        self._update_play_icon()

    def play_next(self):
        if self.playlist:
            self.play_index(0 if self.current_index is None else self.current_index + 1)

    def play_prev(self):
        if self.playlist:
            self.play_index(0 if self.current_index is None else self.current_index - 1)

    def _on_video_end(self, event):
        # вызывается из потока VLC — только ставим флаг, остальное делает главный поток
        self._ended = True

    def seek_relative(self, delta_ms):
        try:
            length = self.player.get_length()
            if length and length > 0:
                self.player.set_time(max(0, min(length - 500, self.player.get_time() + delta_ms)))
        except Exception:
            pass

    def _apply_seek(self):
        try:
            length = self.player.get_length()
            if length and length > 0:
                self.player.set_time(int(self.sl["seek"]["frac"] * length))
        except Exception:
            pass

    def _apply_volume(self):
        try:
            self.player.audio_set_volume(int(self.sl["vol"]["frac"] * 100))
        except Exception:
            pass

    def _tick(self):
        try:
            if self._ended:
                self._ended = False
                self.play_next()
            playing = bool(self.player.is_playing())
            if playing and not self._vol_applied:
                self._apply_volume()
                self._vol_applied = True
            if not self._seeking:
                length = self.player.get_length()
                pos = self.player.get_time()
                if length and length > 0 and pos is not None and pos >= 0:
                    self.sl["seek"]["frac"] = min(1.0, pos / length)
                    self._draw_slider("seek")
                self.canvas.itemconfig("time_txt", text=self._time_text())
        except Exception:
            pass
        self.after(300, self._tick)


CURSORS = ({"n": "size_ns", "s": "size_ns", "e": "size_we", "w": "size_we",
            "ne": "size_ne_sw", "sw": "size_ne_sw", "nw": "size_nw_se", "se": "size_nw_se"} if IS_WIN else
           {"n": "top_side", "s": "bottom_side", "e": "right_side", "w": "left_side",
            "ne": "top_right_corner", "sw": "bottom_left_corner",
            "nw": "top_left_corner", "se": "bottom_right_corner"})


def main():
    if IS_WIN:
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("drakeNier.VideoWidget")
        except Exception:
            pass
    try:
        app = VideoWidget()
        app.mainloop()
    except Exception as exc:
        error_text = traceback.format_exc()
        log_path = os.path.join(BASE_DIR, "error.log")
        try:
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(error_text)
        except Exception:
            pass
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("drakeNier widget — ошибка запуска",
                                 "Не удалось запустить виджет.\n\n%s\n\nПодробности сохранены в файле:\n%s" % (exc, log_path))
        except Exception:
            print(error_text)


if __name__ == "__main__":
    main()
